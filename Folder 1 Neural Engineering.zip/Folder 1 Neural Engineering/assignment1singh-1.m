%BioE2615 Homework 1 
%by Jaspreet Singh
%on 8/31/2023
%creating the wave functions for the two sin waves
%Question 1, part a (see previous examples init assignment 1)
fs=1000;
t=0:0.001:1; 
f=15
%sinwave for for waveform_A=sin(2*pi*f*t)
A = sin(2*pi*15*t);
%sinwave for wave B, note to self:  this notation includes a period as we are
%dealing with computation of waves
B = sin(2*pi*15*t).^5;
%create the matrix
%for a function that has a corresponding pair, like a sin wave and a sin
%wave, to perform an operation (like taking it to the fifth power) you need
%a period 

%matrix
m = length(t);
matrix = zeros(m,5)
matrix(:,1)= A;
matrix(:,2) = B;
matrix(:,3) = A + B;
matrix(:, 4)= A .* B;
matrix(:,5) = A ./ B;

%create subplots

subplot(2, 3, 1);
plot(t, matrix(:, 1), 'b');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('Waveform A (sin(2\pi15t))');

subplot(2, 3, 2);
plot(t, matrix(:, 2), 'r');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('Waveform B (sin(2\pi15t)^5)');

subplot(2, 3, 3);
plot(t, matrix(:, 3), 'g');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('A + B');

subplot(2, 3, 4);
plot(t, matrix(:, 4), 'm');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('A * B');

subplot(2, 3, 5);
plot(t, matrix(:, 5), 'c');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('A / B');subplot(2, 3, 1);
plot(t, matrix(:, 1), 'b');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('Waveform A (sin(2\pi15t))');

subplot(2, 3, 2);
plot(t, matrix(:, 2), 'r');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('Waveform B (sin(2\pi15t)^5)');

subplot(2, 3, 3);
plot(t, matrix(:, 3), 'g');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('A + B');

subplot(2, 3, 4);
plot(t, matrix(:, 4), 'm');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('A * B');

subplot(2, 3, 5);
plot(t, matrix(:, 5), 'c');
xlabel('Time (seconds)');
ylabel('Amplitude (Voltage)');
title('A / B');
title('Waveform Comparison');

% Adjust subplot layout
axis('tight');
grid('on');
    
%% 


%Question 1, part b (create 3 sin waves using sin(x) function)

%the problem gave us these interval x values
x1=(-pi:0.5:pi);
x2=(-pi:0.1:pi);
x3=(-pi:0.01:pi);

%now calculate the y values
y1=sin(x1);
y2=sin(x2);
y3=sin(x3);

%you can use /it for italics or /rm for removed; {} bracket means cell array. Create a cell array of line styles for plotting
line_styles = {'b-', 'r--', 'g:'};

% Create a new figure
figure

% Use hold on to overlay the plots
hold on;

% Loop through the three sine waves and plot them with different line styles
for i = 1:3
    plot(x1, y1, line_styles{i});
end

% Add labels and a legend
xlabel ('Time (seconds(x))');
ylabel('Amplitude (Voltage or sin(x))');
legend('wave 1: 0.5 spacing',  'wave 2: 0.1 spacing', 'wave 3: 0.01 spacing');

% Title and grid
title('Sine Waves with Different Intervals');
grid on;

% I want the overlapping of figures to stop now 
hold off;

%Question 1, part c 
%load the assignment file after saving it in my computers MATLAB folder. it
%won't load but I would open the file, put it into my MATLAB folder, and
%then load it here I have both commands so hopefully one would bring an
%image for me lol 
load tire.mat
load tire copy.mat


%from the assignment, I know that to display images I can use the funtion
%imagesc
imagesc(X)
%fixdistortion
axis image
%add colorbar 
colorbar

%get matrix 3x2
sub_matrix = tire(70:72, 11:12);
%display the values
disp(sub_matrix);

%%

%question 1, part d
%note to self: a series of sine waves can be overlapped to create a square
%wave. this is fourier transformation 
%given information from assignment 
t=[0:0.001:0.2];
y1=sin(2*pi*40*t);
y2=y1;
y2(find(y1>0))=+1;
y2(find(y1<0))=-1;
%what we are actually making - wave with 20Hz and 30 Hz
y1 = sin(2*pi*20*t);
y2 = sin(2*pi*30*t);
%using example given, use the find function for the new wave and new y3 
y3 = y1;
y3(find(y1 > 0)) = +1;
y3(find(y1 < 0)) = -1;

% Create subplots to compare the waveforms
figure;
%1
subplot(2, 2, 1);
plot(t, y1);
xlabel('Time (seconds)');
ylabel('Amplitude');
title('Sine Wave (20 Hz)');
%2
subplot(2, 2, 2);
plot(t, y2);
xlabel('Time (seconds)');
ylabel('Amplitude');
title('Sine Wave (30 Hz)');
%3
subplot(2, 2, [3, 4]);
plot(t, y3);
xlabel('Time (seconds)');
ylabel('Amplitude');
title('Square Wave (20 Hz)');


grid on;

% Adjust subplot layout
sgtitle('Sine and Square Waveforms');

%%
%Question 1, part e
% we need to find the means 
%reload the file for tire 
load tire.mat

%get the mean(x,y)
mean(tire.mat,'all');

% Find pixels above the mean value
 above_mean_indices = find (tire.mat > mean_value);

 %Create a mask matrix with 1s at above-mean indices
  mask = zeros (size ('tire.mat'));
  mask ('above_mean_indices') = 1;

% Apply the mask to the tire matrix
 mask_tire = 'tire.mat'

% I need the two figures so create two images
 figure;

    subplot(1, 2, 1);
    imagesc('tire.mat', []);
    title('Tire Image Origionally Created');

    subplot(1, 2, 2);
    imagesc('masked_tire');
    title('Tire Image Above Mean');
    sgtitle('Tire Image Analysis');
    
%load tiremat
load tire.mat


% name the masktire function with tire 
masktire('tire');






