
%% Part 3: Single Value Decomposition (SVD): PCA for 2D arrays

% Define the folder where your images are stored
% folder = 'C:\Users\Macintosh HD\jaspreetsingh\MATLAB Drive';
folder = pwd;

% List of image filenames
imageFile = 'TSeries-10052015-1158-2053.tif';
nImageLayers = 1000;

% Loop through each image file
imageMatrix = nan(256, 256, 1000);
for fileIdx = 1:nImageLayers
    % Read the current image
    currentImage = imread(fullfile(folder, imageFile), fileIdx);
    % Convert the image to double (assuming the image is in uint8 format)
    currentImageDouble = double(currentImage);
    imageMatrix(:, :, fileIdx) = currentImageDouble;
end

height = size(imageMatrix,1);
width = size(imageMatrix,2);
nFrames = size(imageMatrix,3);

A = reshape(imageMatrix, height*width, nFrames);

% Perform Singular Value Decomposition (SVD)
[U, S, V] = svd(A, "econ");

% #5: Plot the singular values
figure;
semilogy(diag(S));
title(['Singular Values - ' imageFile]);
xlabel('Coefficient Number');
ylabel('Singular Value');

% Find the coefficient # cutoff
% (You may need to interactively choose a suitable cutoff)

% % Reconstruct the vectors using the selected number of coefficients
numCoefficients = 65;
reconstruction = U(:, 1:numCoefficients) * S(1:numCoefficients, 1:numCoefficients) * V(:, 1:numCoefficients)';
% reconstruction = U(:, numCoefficients+1:1000) * S(numCoefficients+1:1000, numCoefficients+1:1000) * V(:, numCoefficients+1:1000)';

% Convert the vectors back into a 2D matrix
reconstructedImage = reshape(reconstruction, height, width, nFrames);

% Display the original and reconstructed images side by side
figure;
for k=1:nFrames
    subplot(1,2,1);
    imagesc(imageMatrix(:,:,k));
    colormap gray;
    subplot(1,2,2);
    imagesc(reconstructedImage(:,:,k));
    colormap gray;
    pause(0.05);
    drawnow limitrate
end