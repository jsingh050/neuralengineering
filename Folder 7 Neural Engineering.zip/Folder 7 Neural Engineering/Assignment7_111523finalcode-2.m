
%% Load an image

% Step 1: Read and display the image
imagePath = 'IMPLANT_C004_GFAP.tif';
img = imread(imagePath);
figure; % tiledlayout(1, 2);
imshow(img, [0, 4095]); title('Original Image');
% nexttile; imshow(histeq(img, 4096)); title('Equalized Image');

%%

% Step 2: Set scale in microns/pixel
scale_microns_per_pixel = 0.621;
img_size_pixels = size(img);
img_size_microns = img_size_pixels * scale_microns_per_pixel;

bin_size_microns = 2; % microns
bin_size_pixels = floor(bin_size_microns / scale_microns_per_pixel);

img_binned = zeros(floor(img_size_pixels ./ bin_size_pixels));
bin_idx = 1:bin_size_pixels:img_size_pixels;

for x = 1:size(img_binned, 2)
    for y = 1:size(img_binned, 1)
        img_binned(y, x) = mean(img(bin_idx(y)+bin_size_pixels-1, bin_idx(x)+bin_size_pixels-1), "all");
    end
end

% figure; % tiledlayout(1, 2);
% imshow(img_binned, [0, 4095]); title('Binned Image');
% % nexttile; imshow(histeq(img_binned), [0, 4095]); title('Equalized Binned Image');

figure;
histogram(img_binned); title(sprintf("Binned Image Histogram (%i um)", bin_size_microns));

%%

% Step 4: Convert to double
img_double = double(img_binned);

% Step 5: Calculate mean and standard deviation
mean_intensity = mean(img_double(:));
std_dev_intensity = std(img_double(:));

% Step 6: Visual confirmation
figure; tiledlayout(1, 2);
nexttile; imagesc(img_double);
title('Original Image');

% Step 7: Find threshold standard deviation variable
threshold_standard_dev = 0.5;  % Adjust as needed

% Step 8: Set pixel threshold value
pixel_threshold = max(mean_intensity - std_dev_intensity * threshold_standard_dev, min(img_double(:)) + 1);

% Step 9: Create thresholded mask
thresholded_mask = img_double < pixel_threshold;

% Display and save thresholded mask
nexttile; imagesc(thresholded_mask);
title(['Thresholded Mask (', num2str(threshold_standard_dev), ' std), Pixels below threshold: ', num2str(sum(thresholded_mask(:)))]);
% saveas(gcf, 'thresholded_mask.png');

%% Steps 10-13: Probe center and edges

figure;
imshow(img, [0, 4095]); title('Original Image');

[x, y] = ginput(1);
img_size = size(img);
x = round(x);
y = round(y);

probe_width = 50;  % microns
probe_thickness = 1;  % microns

probe_width_pixels = round(probe_width / scale_microns_per_pixel);
probe_thickness_pixels = round(probe_thickness / scale_microns_per_pixel);

% Steps 14-16: Create mask arrays
Array2_width = probe_width_pixels;
Array2_height = y - probe_thickness_pixels/2;
Array2 = repmat(flip(1:Array2_height)', 1, Array2_width);
Array1 = zeros(Array2_height, floor((img_size(2) - Array2_width)/2));
Array3 = zeros(Array2_height, ceil((img_size(2) - Array2_width)/2));
Array4 = zeros(img_size(1) - Array2_height, img_size(2));

% Concatenate arrays
array_mask = vertcat(horzcat(Array1, Array2, Array3), Array4);

% Display mask
figure;
imagesc(array_mask);
title('Array Mask');

%% Bin mask

bin_mask = zeros(size(array_mask));
nbins = 15;
% Check whether we can divide Array2 into nbins
Array2_unique = unique(Array2);
if rem(numel(Array2_unique), nbins) ~= 0
    Array2_unique = vertcat(Array2_unique, NaN(nbins - rem(numel(Array2_unique), nbins), 1));
end
% Get the maximum values for each bin (nonoverlapping)
Array2_reshape = reshape(Array2_unique, [], nbins);
bin_maxs = Array2_reshape(end, :);

bin_data = zeros(nbins, 5);
bin_min = 0;
for bin = 1:nbins
    % Create the bin mask for each bin
    bin_max = bin_maxs(bin);
    if isnan(bin_max), bin_max = max(Array2_unique, [], "omitnan"); end
    idx_mask_min = array_mask > bin_min;
    idx_mask_max = array_mask <= bin_max;
    idx_all = idx_mask_min & idx_mask_max;
    bin_mask(idx_all) = 1;
    % Apply the bin mask to copy of original image
    img_temp = double(img);
    img_temp(bin_mask == 0) = 0;
    img_temp_reshape = reshape(img_temp, [], 1);
    img_temp_reshape(img_temp_reshape < pixel_threshold) = 0;
    mean_img_temp = mean(img_temp_reshape) / pixel_threshold; % normalized to pixel threshold
    std_img_temp = std(img_temp_reshape) / pixel_threshold; % normalized to pixel threshold
    % Store data
    bin_data(bin, :) = [bin, bin_min, bin_max, mean_img_temp, std_img_temp];
    % Set the minimum for the next bin
    bin_min = bin_max;
end

% %% PART 3 started 
% % Part 3: Single Value Decomposition (SVD): PCA for 2D arrays
% 
% % Define the folder where your images are stored
% folder = '/path/to/your/images/';
% 
% % List of image filenames
% imageFiles = {
%     'IMPLANT_C001_dapi.tif',
%     'IMPLANT_C002_6e10.tif',
%     'IMPLANT_C003_App.tif',
%     'IMPLANT_C004_GFAP.tif',
%     'CONTROL_C001_dapi.tif',
%     'CONTROL_C002_6e10.tif',
%     'CONTROL_C003_App.tif',
%     'CONTROL_C004_GFAP.tif',
%     'IMPLANT2_C001_DAPI.tif',
%     'IMPLANT2_C002_LAMP1.tif',
%     'IMPLANT2_C003_NeuN.tif',
%     'CONTROL2_C001_DAPI.tif',
%     'CONTROL2_C002_LAMP1.tif',
%     'CONTROL2_C003_NeuN.tif'
% };
% 
% % Loop through each image file
% for fileIdx = 1:length(imageFiles)
%     % Read the current image
%     currentImage = imread(fullfile(folder, imageFiles{fileIdx}));
% 
%     % Convert the image to double (assuming the image is in uint8 format)
%     currentImageDouble = double(currentImage);
% 
%     % Reshape the 2D matrix into a 1D vector
%     vectorizedImage = currentImageDouble(:);
% 
%     % Perform Singular Value Decomposition (SVD)
%     [U, S, V] = svd(vectorizedImage);
% 
%     % Plot the singular values
%     figure;
%     semilogy(diag(S));
%     title(['Singular Values - ' imageFiles{fileIdx}]);
%     xlabel('Coefficient Number');
%     ylabel('Singular Value');
% 
%     % Find the coefficient # cutoff
%     % (You may need to interactively choose a suitable cutoff)
% 
%     % Reconstruct the vectors using the selected number of coefficients
%     numCoefficients = % Your chosen number of coefficients;
%     reconstruction = U(:, 1:numCoefficients) * S(1:numCoefficients, 1:numCoefficients) * V(:, 1:numCoefficients)';
% 
%     % Convert the vectors back into a 2D matrix
%     [height, width] = size(currentImage);
%     reconstructedImage = reshape(reconstruction, height, width);
% 
%     % Display the original and reconstructed images side by side
%     figure;
%     subplot(1, 2, 1);
%     imshow(currentImage, []);
%     title('Original Image');
% 
%     subplot(1, 2, 2);
%     imshow(reconstructedImage, []);
%     title('Reconstructed Image');
% 
%     pause(0.25);
% end





%% Part 3: Single Value Decomposition (SVD): PCA for 2D arrays

% Define the folder where your images are stored
% folder = 'C:\Users\Macintosh HD\jaspreetsingh\MATLAB Drive';
folder = pwd;

% List of image filenames
imageFile = 'TSeries-10052015-1158-2053.tif';
nImageLayers = 1000;

% Loop through each image file
imageMatrix = nan(256, 256, 1000);
for fileIdx = 1:nImageLayers
    % Read the current image
    currentImage = imread(fullfile(folder, imageFile), fileIdx);
    % Convert the image to double (assuming the image is in uint8 format)
    currentImageDouble = double(currentImage);
    imageMatrix(:, :, fileIdx) = currentImageDouble;
end

height = size(imageMatrix,1);
width = size(imageMatrix,2);
nFrames = size(imageMatrix,3);

A = reshape(imageMatrix, height*width, nFrames);

% Perform Singular Value Decomposition (SVD)
[U, S, V] = svd(A, "econ");

% #5: Plot the singular values
figure;
semilogy(diag(S));
title(['Singular Values - ' imageFile]);
xlabel('Coefficient Number');
ylabel('Singular Value');

% Find the coefficient # cutoff
% (You may need to interactively choose a suitable cutoff)

% % Reconstruct the vectors using the selected number of coefficients
numCoefficients = 65;
reconstruction = U(:, 1:numCoefficients) * S(1:numCoefficients, 1:numCoefficients) * V(:, 1:numCoefficients)';
% reconstruction = U(:, numCoefficients+1:1000) * S(numCoefficients+1:1000, numCoefficients+1:1000) * V(:, numCoefficients+1:1000)';

% Convert the vectors back into a 2D matrix
reconstructedImage = reshape(reconstruction, height, width, nFrames);

% Display the original and reconstructed images side by side
figure;
for k=1:nFrames
    subplot(1,2,1);
    imagesc(imageMatrix(:,:,k));
    colormap gray;
    subplot(1,2,2);
    imagesc(reconstructedImage(:,:,k));
    colormap gray;
    pause(0.05);
    drawnow limitrate
end

%%
% Extra Credit - Part 1: Cell counting based analysis

% Assuming you have the probe center and edges from Part 2
% Replace these values with actual probe center and edges
probe_center_x = 512;
probe_center_y = 512;
probe_height = 20;
probe_width = 50;

% Step 4: Display the image using imagesc
figure; hold on;
imagesc(img);
colormap(gray);  % Consider using a grayscale color scheme

probe_left_edge = probe_center_x - probe_width/2;
probe_right_edge = probe_center_x + probe_width/2;
probe_top_edge = probe_center_y + probe_height/2;
probe_bottom_edge = probe_center_y - probe_height/2;

plot([probe_left_edge, probe_right_edge], [probe_top_edge, probe_top_edge], 'r');
plot([probe_left_edge, probe_right_edge], [probe_bottom_edge, probe_bottom_edge], 'r');
plot([probe_left_edge, probe_left_edge], [probe_top_edge, probe_bottom_edge], 'r');
plot([probe_right_edge, probe_right_edge], [probe_top_edge, probe_bottom_edge], 'r');

title('Original Image');

% Step 5: Start a 'for' loop for each bin
num_bins = 10;  % Change this to  desired number of bins
bin_size_height = 20;  % Change this to desired bin size in microns
bin_size_width = 50;

for bin = 1:num_bins

    % Calculate bin edges
    % bin_min_radius = (bin - 1) * bin_size + probe_height;
    bin_min_radius = probe_center_y - bin * bin_size_height;
    bin_max_radius = probe_center_y + bin * bin_size_height;
    bin_left_edge = probe_center_x - bin * bin_size_width;
    bin_right_edge = probe_center_x + bin * bin_size_width;

    plot([bin_left_edge, bin_right_edge], [bin_max_radius, bin_max_radius], 'c');
    plot([bin_left_edge, bin_right_edge], [bin_min_radius, bin_min_radius], 'c');
    plot([bin_left_edge, bin_left_edge], [bin_max_radius, bin_min_radius], 'c');
    plot([bin_right_edge, bin_right_edge], [bin_max_radius, bin_min_radius], 'c');

end

axis tight;

% for bin = 1:num_bins
% 
%     % Calculate bin edges
%     % bin_min_radius = (bin - 1) * bin_size + probe_height;
%     bin_min_radius = bin * bin_size + probe_height;
%     bin_max_radius = bin * bin_size + probe_height;
% 
%     % Calculate the coordinates for the lines
%     left_edge_x = probe_left_edge - bin_min_radius;
%     left_edge_y = probe_center_y;
%     right_edge_x = probe_right_edge + bin_min_radius;
%     right_edge_y = probe_center_y;
% 
%     min_radius_line_x = [left_edge_x, right_edge_x];
%     min_radius_line_y = [left_edge_y, right_edge_y];
% 
%     left_edge_x = probe_center_x - bin_max_radius;
%     right_edge_x = probe_center_x + bin_max_radius;
% 
%     max_radius_line_x = [left_edge_x, right_edge_x];
%     max_radius_line_y = [left_edge_y, right_edge_y];
% 
%     left_edge_x = probe_center_x - bin_min_radius;
%     left_edge_y = probe_center_y - bin_max_radius;
%     right_edge_x = probe_center_x + bin_min_radius;
%     right_edge_y = probe_center_y - bin_max_radius;
% 
%     left_edge_line_x = [left_edge_x, right_edge_x];
%     left_edge_line_y = [left_edge_y, right_edge_y];
% 
%     top_edge_y = probe_center_y + bin_max_radius;
%     bottom_edge_y = probe_center_y + bin_max_radius;
% 
%     right_edge_line_x = [left_edge_x, right_edge_x];
%     right_edge_line_y = [left_edge_y, right_edge_y];
% 
%     % Plot the lines
%     % plot(min_radius_line_x, min_radius_line_y, 'r');
%     % plot(max_radius_line_x, max_radius_line_y, 'r');
%     plot(left_edge_line_x, left_edge_line_y, 'c');
%     plot([left_edge_x, left_edge_x], [left_edge_y, right_edge_y], 'c');
%     plot(right_edge_line_x, right_edge_line_y, 'c');
% 
%     % % Save/print figure for each bin
%     % saveas(gcf, ['bin_', num2str(bin), '_image.png']);
% 
% end
